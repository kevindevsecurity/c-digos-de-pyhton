# for loops para string
Nome = input("Digite seu nome:") 
Resultado = Nome

for letra in Resultado:  
    print(f'{letra} está dentro da palavra', Nome)  
