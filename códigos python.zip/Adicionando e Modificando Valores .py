#Adicionando e Modificando Valores 
pessoa = {
    "nome": "Alice", 
    "idade": 25,
    "cidade": "São Paulo"
}
pessoa["profissao"] = "Engenharia"
pessoa["idade"] = 26
print(pessoa)