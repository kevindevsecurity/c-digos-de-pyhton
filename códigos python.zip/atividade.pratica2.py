'''Crie duas variáveis com dois valores numéricos inteiros 
digitados pelo usuário, caso o valor do primeiro número for 
maior que o do segundo, exiba em tela uma mensagem de 
acordo, caso contrário, exiba em tela uma mensagem dizendo 
que o primeiro valor digitado é menor que o segundo:'''

# Solicita ao usuário que digite dois números inteiros
num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))

# Verifica qual número é maior e exibe a mensagem correspondente
if num1 > num2:
    print("O primeiro valor digitado é maior que o segundo.")
else:
    print("O primeiro valor digitado é menor que o segundo.")
