'''Adicione o elemento 'Eliana' na lista nomes, 
especificamente na terceira posição da lista:'''

# Lista inicial
nomes = ['Ana', 'Carlos', 'Daiane', 'Fernando', 'Maria']

# Insere 'Eliana' na terceira posição (índice 2)
nomes.insert(2, 'Eliana')

# Exibe a lista modificada
print(nomes)
