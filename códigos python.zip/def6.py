def verificar_idade(idade):
    if idade >= 18:
        return "Maior de idade"
    else:
        return "Menor de idade"

print(verificar_idade(17))  
print(verificar_idade(18))  

