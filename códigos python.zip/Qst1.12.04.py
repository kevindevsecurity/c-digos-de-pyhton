# Atividade Prática 1
#Crie um programa para exibir os números de 1 a 100

for numero in range(1, 101):
    print(numero)




