'''Crie um programa que lê um valor de início e um valor de fim,
exibindo em tela a contagem dos números dentro desse 
intervalo.'''

# Solicita ao usuário os valores de início e fim
inicio = int(input("Digite o valor de início: "))
fim = int(input("Digite o valor de fim: "))

# Exibe a contagem dentro do intervalo
print(f"Contagem de {inicio} até {fim}:")
for numero in range(inicio, fim + 1):
    print(numero)
