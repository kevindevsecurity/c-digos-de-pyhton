import pyautogui 
import time

time.sleep(2)

# Pressiona a tecla Windows (Iniciar)
pyautogui.press('win')
time.sleep(1)

# Digita o nome do programa (ex: "calculadora")
pyautogui.write("calculadora", interval=0.1)

# Pressiona Enter para
pyautogui.press("enter")