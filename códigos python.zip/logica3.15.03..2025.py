#Criação do Outer for loop
for numero1 in range(5):
    print(numero1)

    #Criação do Inner for loop
    for numero2 in range(5):
        print(numero1, numero2)