frutas = ["maçã", "banana", "uva"]
for fruta in frutas:
    print(fruta)