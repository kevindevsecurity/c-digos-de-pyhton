dados = ["Caroline Paola da Silva", 0, 1.70, True]
print(f'Nome: {dados[0]}')
print(f'Filhos: {dados[1]}')
print(f'Estatura: {dados[2]:.2f}m')
if dados[3]== True:
    print("Usa Instagram: sim")
else:
    print("Usa Instagram: Não")
