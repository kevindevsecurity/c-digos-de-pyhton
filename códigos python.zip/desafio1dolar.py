#Conversão do real para o dolar

real = float(input("Digite o valor do real que vai gastar:"))
dolar = float(input("Digite o valor do dolar:"))
total = real / dolar
print("A conversão é", total)