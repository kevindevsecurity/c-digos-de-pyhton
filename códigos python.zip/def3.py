def somar_todos(*numeros):
    return sum(numeros)
print(somar_todos(4,5))