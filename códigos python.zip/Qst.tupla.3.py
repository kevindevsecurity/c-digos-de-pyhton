#3. Tamanho da tupla
tupla = ('a', 'b', 'c', 'd')
print(len(tupla))