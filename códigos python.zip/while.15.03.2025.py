contador = 0
while contador < 5:
    print(f' valor do contador é {contador}')
    contador += 1