#4.Verificando se uma chave existe
pessoa = {
    "nome": "João",
    "idade": 30,
    "cidade": "Rio de Janeiro"
}
if "telefone" in pessoa:
    print("A chave 'telefone' existe no dicionário.")
else:
    print("A chave 'telefone' não existe no dicionário.")

