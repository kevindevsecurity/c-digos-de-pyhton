'''Escreva um programa que leia um valor em metros e o exiba convertido em 
milímetros.'''

# Solicita ao usuário que insira um valor em metros
metros = float(input("Digite o valor em metros: "))

# Converte metros para milímetros
milimetros = metros * 1000

# Exibe o valor em milímetros
print("O valor em milímetros é:", milimetros)
