#5. Percorrendo um dicionário
precos = {
    "Banana": 3.50,
    "Maçã": 2.00,
    "Laranja": 4.00
}

for produto, preco in precos.items():
    print(f"{produto}: R$ {preco:.2f}")
