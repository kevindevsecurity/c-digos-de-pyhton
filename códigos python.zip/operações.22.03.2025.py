frutas = ["maçã", "banana", "uva"]
print(frutas[0])
print(frutas[2])
print(frutas[-1])