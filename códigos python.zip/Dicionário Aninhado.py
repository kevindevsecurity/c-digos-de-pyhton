#Dicionário Aninhado
alunos = {
    "Alice": {"idade": 25, "curso": "Engenharia"},
    "Bob": {"idade": 22, "curso": "Medicina"}
}
print(alunos["Alice"]["curso"])
