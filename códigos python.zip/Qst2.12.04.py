# Atividade Prática 2
#Faça programa anterior de forma a perguntar também o valor depositado mensalmente. Esse valor será depositado no início de cada mês, 
#e você deve considerá-lo para o cálculo de juros do mês seguinte

valor_inicial = float(input("Digite o valor inicial: "))
juros = float(input("Digite a taxa de juros mensal (em %): "))
deposito = float(input("Digite o valor depositado mensalmente: "))
meses = int(input("Digite o número de meses: "))

saldo = valor_inicial
for mes in range(1, meses + 1):
    saldo += deposito
    saldo += saldo * (juros / 100)
    print(f"Saldo ao final do mês {mes}: R$ {saldo:.2f}")
