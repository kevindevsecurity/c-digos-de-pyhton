import pyautogui
pyautogui.alert("Cuidado! Essa é uma mensagem automática.")