qtde = int(input("quantos termos do fibonacci você deseja?"))
anterior = 0
atual = 1
contador = 1

while contador <= qtde:
    print('{} -'.format (atual), end = ' ')
    proximo = anterior + atual
    anterior = atual
    atual = proximo 
    contador +=1
print("fim do programa de Fibonacci")
