'''Crie uma variável com valor inicial 0, enquanto o valor dessa
variável for igual ou menos que 10, exiba em tela o próprio valor 
da variável. A cada execução a mesma deve ter seu valor 
atualizado, incrementado em 1 unidade.'''

# Inicializa a variável com valor 0
numero = 0

# Enquanto o valor da variável for menor ou igual a 10
while numero <= 10:
    print(numero)
    numero += 1  # Incrementa a variável em 1 unidade a cada execução
