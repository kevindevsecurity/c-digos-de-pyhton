import tkinter as tk 

def converter():
    try:
        valor_dolar = float(entry_dolar.get())
        cotacao_real = float(entry_cotacao.get())
        resultado = valor_dolar * cotacao_real
        label_resultado.config(text=f"R$ {resultado:.2f}")
    except ValueError:
        label_resultado.config(text="Entrada inválida")

janela = tk.Tk()
janela.title("Conversor de Moeda")

label_dolar = tk.Label(janela, text="Valor em Dólar:")
label_dolar.pack()

entry_dolar = tk.Entry(janela)
entry_dolar.pack()

label_cotacao = tk.Label(janela, text="Cotação do Real:")
label_cotacao.pack()

entry_cotacao = tk.Entry(janela)
entry_cotacao.pack()

botao_converter = tk.Button(janela, text="Converter", command=converter)
botao_converter.pack()

label_resultado = tk.Label(janela, text="R$ 0.00")
label_resultado.pack()

janela.mainloop()



