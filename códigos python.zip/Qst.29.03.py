#Criar e imprimir uma lista
lista = [1, 2, 3, 4, 5]
print(lista)

#Acessar a lista
numero = [1, 2, 3, 4, 5]
print(numero[0])
print(numero[-1])

#Remover um item da lista
rem = [1, 2, 3, 4, 5]
rem.remove (3)

#Percorrer uma lista com um loop
dados = [1, 2, 3, 4, 5]
for x in dados:
    print(x)

#Ordenar uma lista
numeros = [5, 2, 3, 4, 1]
numeros.sort()
print(numeros)

numeros = [5, 2, 3, 4, 1]
print("Maior", max(numeros))
print("Menor", min(numeros))

#Contar elementos na lista
numeros = [5, 2, 3, 4, 1]
print("Quantidade de elementos:", len(numeros))

#Juntar duas listas
numeros = [5, 2, 3, 4, 1]
outra_lista = [7, 8, 9]
concatenada = numeros + outra_lista
print(concatenada)



