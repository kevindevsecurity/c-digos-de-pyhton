'''Peça para que o usuário digite um número, em seguida exiba em
tela uma mensagem dizendo se tal número é PAR ou se é ÍMPAR:'''

while True:
    # Solicita ao usuário um número float
    numero = float(input("Digite um número (ou digite 0 para sair): "))
    
    # Condição de saída
    if numero == 0:
        print("Encerrando o programa...")
        break
    
    # Verifica se o número é par ou ímpar
    if numero % 2 == 0:
        print(f"O número {numero} é PAR.")
    else:
        print(f"O número {numero} é ÍMPAR.")
