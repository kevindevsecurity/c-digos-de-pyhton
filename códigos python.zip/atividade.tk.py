from tkinter import *
janela = Tk()
janela.mainloop()
