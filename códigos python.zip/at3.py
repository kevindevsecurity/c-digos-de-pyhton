#Definindo as variavéis 
num1 = 52
num2 = 106

#Calculando a multiplicação
resultado_multiplicacao = num1 * num2

#Calculando a divisão 
resultado_divisão = num1 / num2

# Exibindo os resultados
print("O resultado da multiplicação de", num1, "e", num2, "é:", resultado_multiplicacao)
print("O resultado da divisão de", num1, "por", num2, "é:", resultado_divisão)
