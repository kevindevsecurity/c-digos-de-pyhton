#FIltrando números pares de uma tupla
tupla = (10, 15, 20, 25, 30, 35)
pares = tuple(x for x in tupla if x % 2 == 0)
print(pares)
