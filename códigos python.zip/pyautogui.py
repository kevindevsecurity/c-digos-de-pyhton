import pyautogui
import time 
import os

# Espera 2 segundos para dar tempo de você se preparar
time.sleep(2)

# Abre o Bloco de Notas (no Windows)
os.system("start notepad")
time.sleep(1.5)

# Digita uma mensagem
pyautogui.write("Olá! Esta mensagem foi digitada automaticamente.", interval=0.1)

# Pressiona Enter
pyautogui.press("enter")
pyautogui.write("Automação simples com Python.", interval=0.1)