import pyautogui
import time

# Espera 2 segundos
time.sleep(2)

# Digita o texto como se fosse o teclado
pyautogui.write("Automação com PyautoGUI é fácil!", interval=0.1)

# Pressiona Enter
pyautogui.press("enter")
