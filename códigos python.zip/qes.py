import pyautogui

# apertar a tecla windows do teclado
pyautogui.press('Win')

# digitar o chrome
pyautogui.write('chrome') 

# aperte a tecla enter
pyautogui.press('enter')

