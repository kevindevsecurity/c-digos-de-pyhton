'''3. Verifique se o valor de num1 é igual ou menor que 100:'''

num1 = 100 
num2 = 89  

resultado = num1 <= num2

print(resultado)
