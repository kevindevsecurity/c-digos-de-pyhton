import pygame
import random

pygame.init()

width, height = 800, 600
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Desvie do Inimigo")

WHITE = (255,255,255)
RED = (255,0,0)
BLUE = (0,0,255)

player_size = 50
player_x = 100
player_y = 100
player_speed = 5

enemy_size = 50
enemy_x = random.randint(0, width - enemy_size)
enemy_y = 0
enemry_speed = 5

clock = pygame.time.Clock()

def colidiu(x1, y1, x2, y2, size):
    return (x1 < x2 + size and
            x1 + size > x2 and
            y1 < y2 + size and
            y1 + size > y2)

running = True 

while running:
    clock.tick(60) # 60 FPS
    window.fill(WHITE)

    for event in pygame.event.get():
       if event.type == pygame.QUIT:
          running = False
    
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and player_x > 0:
       player_x -= player_speed

    if keys[pygame.K_RIGHT] and player_x < width - player_size:
       player_x += player_speed

    if keys[pygame.K_UP] and player_y > 0:
       player_y -= player_speed

    if keys[pygame.K_DOWN] and player_y < height - player_size:
       player_y += player_speed

    enemy_y += enemry_speed

    if enemy_y > height:
        enemy_y = 0
        enemy_x = random.randint(0, width - enemy_size)

    if colidiu(player_x, player_y, enemy_x, enemy_y, player_size):
       print("Game Over!")
       running = False

    pygame.draw.rect(window, RED, (player_x, player_y, player_size, player_size))
    pygame.draw.rect(window, BLUE, (enemy_x, enemy_y, enemy_size, enemy_size))

    pygame.display.update()

pygame.quit()

