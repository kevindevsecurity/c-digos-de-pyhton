faturamento = int(input("A quantidade de faturamento:"))
custo = int(input("A quantidade de custo:"))

lucro = faturamento - custo

print("O resultado dos custos é:", lucro)