import pyautogui
import time

time.sleep(3)

for i in range(5):
    pyautogui.write(f"Mensagem número {i+1}", interval=0.1)
    pyautogui.press("enter")
    