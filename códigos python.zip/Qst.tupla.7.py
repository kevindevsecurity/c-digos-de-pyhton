#Encontrando o maior e menor valor em uma tupla
numeros = (12, 45, 2, 89, 5)
print(max(numeros))
print(min(numeros))