#Acessando Valores
pessoa = {
    "nome": "Alice", 
    "idade": 25,
    "cidade": "São Paulo"
}
print(pessoa["nome"])
print(pessoa["idade"])
print(pessoa["cidade"])