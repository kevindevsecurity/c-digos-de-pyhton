#2. Verificando a existÊncia de um elemento
numeros = (10, 20, 30, 40, 50)
print(30 in numeros)