#Métodos Úteis
d = {"a": 1, "b": 2, "c": 3}
print(d.keys())
print(d.values())
print(d.items())
d.clear()
print(d)