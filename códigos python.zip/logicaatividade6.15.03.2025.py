'''6. Verifique se os valores de num1 ou de num2 são iguais ou maiores que 
100:'''

# Solicitando que o usuário digite um número
num = int(input("Digite um número: "))

# Verificando se o número é par ou ímpar
if num % 2 == 0:
    print(f"O número {num} é PAR.")
else:
    print(f"O número {num} é ÍMPAR.")

