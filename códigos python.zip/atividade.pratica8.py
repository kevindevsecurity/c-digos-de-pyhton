'''Dada a seguinte lista: nomes = ['Ana', 'Carlos', 'Daiane',
'Fernando', 'Maria'], substitua o terceiro elemento da lista por
'Jamile':'''

# Lista inicial
nomes = ['Ana', 'Carlos', 'Daiane', 'Fernando', 'Maria']

# Substituição do terceiro elemento (índice 2)
nomes[2] = 'Jamile'

# Exibição da lista modificada
print(nomes)
