# Digita a URl e acessa o Google
import pyautogui
pyautogui.write("Como usar pyautogui", interval=0.1)
pyautogui.press("enter")