'''Crie uma estrutura de repetição que percorre a string ‘Nikola Tesla’, 
exibindo em tela letra por letra desse nome:'''

# Definindo a string
nome = str('Nikola Tesla')

# Estrutura de repetição para percorrer cada letra
for letra in nome:
    print(letra)  
