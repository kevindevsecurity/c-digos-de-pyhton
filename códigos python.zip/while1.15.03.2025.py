resp = input('Deseja inicia o progrma? s/n ')

while resp != "s" and resp != "n":
    resp = input('resposta invalida!!!! contiunuar? s/n')
    print('resposta ok. Vamos continuar o programa')
    print("fim do programa")

