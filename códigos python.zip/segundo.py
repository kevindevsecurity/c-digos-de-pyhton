print('kevin.ferreira0510@gmail.com')
print('18 anos')