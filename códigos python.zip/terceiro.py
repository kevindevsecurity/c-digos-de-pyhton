# declaração de variáveis
x = 30
nome = "João"
preço = 15.6

#imprimir na tela
print(" valor de x é: ", x)
print(" O nome é:", nome)
print(" O valor decimal é:", preço)
