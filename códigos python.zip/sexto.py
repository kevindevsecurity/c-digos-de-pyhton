x = 10
x2 = 10
x -= 5
x2 = x2 - 5
print(x)


