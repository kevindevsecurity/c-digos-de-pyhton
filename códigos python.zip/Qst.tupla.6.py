#6. Contagem de elementos em uma tupla
valores = (1, 2, 2, 3, 3, 3, 4, 4, 4, 4)
print(valores.count(3))
