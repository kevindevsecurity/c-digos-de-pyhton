nome = "João"
idade = 30
altura = 1.75
mensagem = "Olá meu nome é {} tenho {} de vida e minha altura é {}".format(nome, idade, altura)
print(mensagem)