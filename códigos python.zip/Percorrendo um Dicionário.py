#Percorrendo um Dicionário
pessoa = {
    "nome": "Alice", 
    "idade": 25,
    "cidade": "São Paulo"
}
for chave in pessoa:
    print(chave, ":", pessoa[chave])
for chave, valor in pessoa.items():
    print(f"{chave}: {valor}")
