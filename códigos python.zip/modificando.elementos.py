frutas = ["maçã", "banana", "uva"]
frutas[1] = "laranja"
print(frutas)