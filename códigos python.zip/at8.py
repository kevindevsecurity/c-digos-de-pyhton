c = int(input("Digite a Temperatura em celsius:"))

f = ((9 * c) / 5) + 32

print("A temperatura em fahrenheit", f)
