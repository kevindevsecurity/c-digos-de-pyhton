'''
Converta as seguintes expressões matemáticas para que possam ser calculadas usando o interpretador Python
1. 10 + 20 * 30
2. 4 ** 2 ÷ 30 
3. (9 ** 4 + 2) x 6 – 1 
'''

#primeira conta

a = 10
b = 20
c = 30
d = a+b*c
print("a resposta é:", d)

#segunda conta
v1 = 4
v2 = 2
v3 = 30
v4 = v1**v2 / v3
print("a resposta é:", v4)

#terceira conta
v1 = 9
v2 = 4
v3 = 2
v4 = 6
v5 = 1
v6 = (v1**v2 + v3) * v4 - v5
print("a resposta é:", v6)
