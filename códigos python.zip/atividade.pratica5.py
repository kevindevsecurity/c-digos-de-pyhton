'''Crie uma lista com 8 elementos de uma lista de compras de
supermercado, por meio de um laço de repetição for liste
individualmente cada um dos itens dessa lista'''

# Lista de compras com 8 elementos
lista_compras = ["Arroz", "Feijão", "Leite", "Pão", "Ovos", "Frutas", "Carne", "Café"]

# Loop para exibir cada item individualmente
for item in lista_compras:
    print(item)
