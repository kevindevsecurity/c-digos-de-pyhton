def calcular_media(nota1, nota2, nota3, nota4):
    return (nota1 + nota2 + nota3 + nota4) / 4

print(calcular_media(3, 10, 10, 10)) 
