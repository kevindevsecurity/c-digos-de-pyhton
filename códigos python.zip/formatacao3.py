nome = "Maria"
idade = 25

mensagem = f"Olá, meu nome é {nome} e tenho {idade} anos."
print(mensagem)
