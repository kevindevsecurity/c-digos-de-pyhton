frutas = ["maçã", "banana", "uva"]
print(len(frutas))
