from tkinter import *
def click():
    etq['text']='Olá', entrada.get()

janela = Tk()
janela.title("Kevin")
janela.iconbitmap('linux.ico')
janela['background']=('white')

entrada= Entry(janela,width=80)
entrada.pack()
entrada.get()
etq=Label(janela,text="Olá Mundo")
etq.pack()

bt=Button(janela,text='Clique aqui', command=click)
bt.pack()
janela.geometry('500x400+50+40')
janela.mainloop()