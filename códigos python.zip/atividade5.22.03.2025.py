'''5. Reescreva o programa anterior para escrever os 10 primeiros múltiplos de 3.'''

#Reescrevendo o programa para 10 primeiros números múltiplos de 3.

contador = 1
multiplo = 1

while contador <= 10:  
    if multiplo % 3 == 0:  
        print(multiplo)
        contador += 1
    multiplo += 1 

