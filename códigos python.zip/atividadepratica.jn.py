from tkinter import *
def clik():
    etq['text']=" Botão clicado"

janela = Tk()
janela.title("Kevin")
janela.iconbitmap('linux.ico')
janela['background']=('Black')
janela.geometry('500x400+50+200')
#Etiqueta ou label
etq=Label(janela, text="Olá Mundo", width= 10,height=5,bg='white', fg='green')
etq.pack()
#Inserindo Botão
botao= Button(janela, text='Botão', bg='white', fg='red', width= 10,height=5, command=clik)
botao.pack()
bt=Button(janela, text='Fechar',bg='white',fg='green', command=quit)
bt.pack()
janela.geometry('500x400+50+200')
janela.mainloop()