'''5. Verifique se os valores de num1 ou de num2 são iguais ou maiores que 
100:'''

num1 = 100  
num2 = 89   

if num1 >= 100 and num2 >= 100:  
    print("num1 e num2 são menores ou iguais a 100.")
elif num1 == num2:  
    print("num1 e num2 são iguais.")
else:
    print("num1 e num2 não atendem às condições.")