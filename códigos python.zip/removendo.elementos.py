frutas = ["maçã", "banana", "uva"]
frutas.remove("uva")
print(frutas)

removido = frutas.pop()
print(removido)