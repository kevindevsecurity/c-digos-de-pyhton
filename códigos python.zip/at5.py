# Pedindo a entrada dos valores
x = float(input("Digite o primeiro valor: "))
y = float(input("Digite o segundo valor: "))

# Calculando as operações
resultado1 = x + y
resultado2 = x - y
resultado3 = x * y
resultado4 = x / y

# Exibindo os resultados
print("A soma é:", resultado1)
print("A subtração é:", resultado2)
print("A multiplicação é:", resultado3)
print("A divisão é:", resultado4)