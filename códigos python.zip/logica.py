x = 10
y = 5
z = x == y
print(z)

x = 10
y = 5
z = x > y
print(z)

x = 10
y = 5
z = x < y
print(z)

x = 10
y = 5
z = x >= y
print(z)

x = 10
y = 5
z = x <= y
print(z)

x = 10
y = 5
z = x != y
print(z)
