#5. Desempacote a tupla

dados = ("joão", 25, "Brasil")
a, b, c = dados
print(a)
print(b)
print(c)

