'''
Para preparar um delicioso café, siga estes passos: Primeiro, aqueça a água até ferver (aproximadamente 200 ml para uma xícara de café). 
Enquanto a água aquece, prepare o filtro de café. Coloque o filtro de papel no porta-filtro e molhe-o com água quente para remover o gosto do papel e esquentar o porta-filtro.
Em seguida, meça a quantidade de café moído. Utilize cerca de 10 gramas de café para cada 180 ml de água. Coloque o café moído no filtro de papel já preparado.
Agora, adicione um pouco de água quente sobre o café moído, apenas o suficiente para molhá-lo completamente. Espere cerca de 30 segundos para que o café "floresça", 
liberando gases presos e melhorando o sabor.
Continue a derramar lentamente o restante da água quente sobre o café moído, fazendo movimentos circulares para garantir uma extração uniforme. Certifique-se de que toda a água
passe pelo café moído e filtre para a jarra abaixo.
Quando toda a água tiver passado pelo café moído e estiver na jarra, remova o porta-filtro. Sirva o café quente em uma xícara e personalize ao seu gosto, adicionando açúcar, 
leite ou qualquer outro condimento de sua preferência.
'''
