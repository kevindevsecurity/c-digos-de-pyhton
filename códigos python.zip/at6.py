# Pedindo a entrada dos valores inteiros
num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))

# Calculando a soma
resultado = num1 + num2

# Exibindo o resultado
print("A soma de", num1, "e", num2, "é:", resultado)
