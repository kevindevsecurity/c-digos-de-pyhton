#Exemplo 1: Criando e Chamando uma Função

def saudacao():
    print("Olá Bem-vindo ao Python")
saudacao()

#Exemplo 2: Função com Parâmetros
def somaria(a,b):
    return a + b
resultado = somaria(5, 3)
print("Soma:", resultado)

#Exemplo 3: Função com valor Padrão
def apresentar(nome="Visitante"):
    print(f"Olá, {nome}!")
apresentar()
apresentar("Ana")

#Exemplo 4: Função com Vários Parâmetros

def somar_todos(*numeros):
    return sum(numeros)
print(somar_todos(1,2,3,4,5))

#Resumo
#1. def define uma função
#2. As funções podem ter parâmetros e rotornar valores.
#3. Tornam o código mais eficiente e reutilizável

