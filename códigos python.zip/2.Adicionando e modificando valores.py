#2.Adicionando e modificando valores
pessoa = {
    "nome": "João",
    "idade": 30,
    "cidade": "Rio de Janeiro"
}
pessoa["profissao"] = "Engenheiro"
pessoa["idade"] = 31
print(pessoa)

