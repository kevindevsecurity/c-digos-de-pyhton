#Definindo as variavéis
num1 = 52
num2 = 106

#Subtraindo as variavéis
resultado = num1 - num2 

# Exibindo o resultado
print("O resultado da subtração de", num1, "e", num2, "é:", resultado)
