a = True
b = False
c = True

#Questão 1
Q1 = a and a 
print(Q1)

#Questão 2
Q2= b and b 
print(Q2)

#Questão 3
Q3= not c
print(Q3)

#Questão 4
Q4 = not b
print(Q4)

#Questão 5
Q5= not a
print(Q5)

#Questão 6
Q6= a and b
print(Q6)

#Questão 7
Q7= b and c
print(Q7)

#Questão 8
Q8= a or c
print(Q8)

#Questão 9
Q9= b or c
print(Q9)

#Questão 10
Q10= c or a
print(Q10)

#Questão 11
Q11= c or b
print(Q11)

#Questão 12
Q12= c or c
print(Q12)

#Questão 13
Q13= b or b
print(Q13)
