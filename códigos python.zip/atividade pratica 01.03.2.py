'''Escreva um programa que pergunte a quantidade de km percorridos por um carro 
alugado pelo usuário, assim como a quantidade de dias pelos quais o carro foi 
alugado. Calcule o preço a pagar, sabendo que o carro custa R$ 60 por dia e R$ 
0,15 por km rodado.'''

# Solicita ao usuário que insira a quantidade de km percorridos
km_percorridos = float(input("Digite a quantidade de km percorridos: "))

# Solicita ao usuário que insira a quantidade de dias de aluguel
dias_alugados = int(input("Digite a quantidade de dias pelos quais o carro foi alugado: "))

# Calcula o preço a pagar
preco_por_dia = 60.0
preco_por_km = 0.15
resultado = total_a_pagar = (dias_alugados * preco_por_dia) + (km_percorridos * preco_por_km)

# Exibe o valor total a pagar
print("O preço a pagar é:", resultado)
