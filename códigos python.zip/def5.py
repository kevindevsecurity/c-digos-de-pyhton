def dobrar_numero(numero):
    return numero * 2

print(dobrar_numero(62))  
