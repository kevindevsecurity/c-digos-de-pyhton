#1. Altere o programa anterior para exibir os resultados no mesmo formato de uma tabuada: 2x1 = 2, 2x2 = 4

numero = int(input("Digite um número para ver sua tabuada: "))
multiplicador = 1

while multiplicador <= 10:
    print(f"{numero}x{multiplicador} = {numero * multiplicador}")
    multiplicador += 1
