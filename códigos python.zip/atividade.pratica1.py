'''Verifique se o valor de num1 consta nos elementos de lista1. 
Sendo num1 = 100 e lista1 = [10, 100, 1000, 10000, 100000].'''

num1 = 100
lista1 = [10, 100, 1000, 10000, 100000]

# Verifica se num1 está na lista
if num1 in lista1:
    print(f"{num1} está presente na lista.")
else:
    print(f"{num1} não está presente na lista.")
