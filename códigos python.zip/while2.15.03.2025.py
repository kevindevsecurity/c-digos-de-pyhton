n = int(input('Digite um número para ser somado: [999 - para parar]'))
soma = 0
while n!= 999:
    soma+= n
    n = int(input('Digite outro número para ser somado com os anteriores: 999 - para sair'))
    print("soma = {}".format(soma))
    