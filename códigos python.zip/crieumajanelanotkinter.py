#Tamanho da bandeira
largura = 300
altura = 200

#Criar o canvas com fundo branco
canvas = Canvas(janela, width=largura,height=altura, bg="white")
canvas.pack()

