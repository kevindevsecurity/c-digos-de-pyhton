#Faça uma divisão que de um resultado inteiro

div = int(input("Digite um número:"))
número = int(input("Digite o número:"))
total = div // número
total2 = div / número
total3 = div % número
print("A resposta da divisão é:", total)
print("A resposta da divisão é:", total2)
print("A resposta da divisão é:", total3)