'''1. Dadas duas variáveis num1 e num2 com valores 100 e 89,
respectivamente, verifique se o valor de num1 é maior que o de num2:'''

num1 = 100 
num2 = 89  

resultado = num1 > num2

print(resultado)
