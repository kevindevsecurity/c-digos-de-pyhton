#1. Crindo e acessando elementos 
tupla = (1, 2, 3, 4, 5)
print(tupla[2]) 