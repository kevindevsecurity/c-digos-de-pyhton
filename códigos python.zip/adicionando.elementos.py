frutas = ["maçã", "banana", "uva"]
frutas.append("manga")
print(frutas)

frutas.insert(1, "morango")
print(frutas)