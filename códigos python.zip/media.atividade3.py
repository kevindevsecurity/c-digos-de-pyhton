#Inserir primeira nota
nota1 = int(input("Informe a nota do bimestre 1 (0-100):"))

#Inserir segunada nota
nota2 = int(input("Informe a nota do bimestre 2 (0-100):"))

#Calculo de média
média=(nota1 + nota2) / 2

#Estruturar condicional
Aprovado = média >= 60
Reprovado = média <= 60

#Exibe o resultado
if média >= 60:
    print("Aprovado")
else:
    print("Reprovado")
    
