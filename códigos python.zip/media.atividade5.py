# Escreva um programa que leia dois números e pergunte qual operação você deseja realizar.
# Você deve poder calcular soma (+), subtração (-), multiplicação (*) e divisão (/).
# Exiba o resultado da operação solicitada.

# Lendo os números
numero1 = float(input("Escolha o número 1: "))
numero2 = float(input("Escolha o número 2: "))

# Perguntando a operação desejada
op = input("Qual é a operação que você quer fazer (+, -, *, /): ")

# Realizando a operação e exibindo o resultado
if op == "+":
    conta = numero1 + numero2
elif op == "-":
    conta = numero1 - numero2
elif op == "*":
    conta = numero1 * numero2
elif op == "/":
    conta = numero1 / numero2
else:
    conta = "Operação inválida"

print(f"O resultado de {numero1} {op} {numero2} = {conta}")
