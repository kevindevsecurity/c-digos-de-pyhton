"""Escreva um programa que pergunte a distância que um passageiro deseja percorrer em km. Calcule o preço da passagem, cobrando R$ 0,50 por km para viagens de até de 200 km,
e R$ o,45 para viagens mais longas"""

# Pergunte a distância:
distancia = float(input("Digite a distância que deseja percorrer em km: "))

#Calculando o preço da passagem:
preço = distancia * 0.50 if distancia <= 200 else distancia * 0.45

#Exibindo o resultado:
print(f"O preço da passagem é: R$ {preço:.2f}")