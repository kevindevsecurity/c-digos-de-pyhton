#Definindo a variavél
num1 = 51

#Calculando a potência
resultado = num1 ** 8

#Exibindo o resultado
print("O valor de", num1, "elevado à oitava potência", "é", resultado)