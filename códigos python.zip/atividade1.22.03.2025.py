'''1. Modifique o programa para exibir os números de 1 a 100.'''

#Exibindo o programa dos números de 1 a 100
Números = 1
while Números < 101:
    print(f' valor do contador é {Números}')
    Números += 1