#Crie um comentário de no máximo uma linha.
#Aprendendo a Linguagem Pyhton no Senai com o professor Douglas.