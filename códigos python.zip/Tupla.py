#Criando uma Tupla
tupla1 = (1, 2, 3, 4)
tupla2 = ("Python", 10, 3.14, True)
tupla3 = (42,)
tupla4 = "a", "b", "c"

#Acessando Elementos 
tupla = (10, 20, 30, 40)
print(tupla[0])
print(tupla[-1])
print(tupla[1:3])

#Operações com Tuplas
tupla = (1, 2, 3)
nova_tupla = tupla + (4, 5)
print(nova_tupla)

print(len(tupla))
print(2 in tupla)

#Desempacotando
tupla = (10, 20, 30)
a, b, c = tupla 
print(a, b, c)

#1. Crindo e acessando elementos 
tupla = (1, 2, 3, 4, 5)
print(tupla[2])  

#2. Verificando a existÊncia de um elemento
numeros = (10, 20, 30, 40, 50)
print(30 in numeros)

#3. Tamanho da tupla
tupla = ('a', 'b', 'c', 'd')
print(len(tupla))

#4. Concatenação de tuplas

