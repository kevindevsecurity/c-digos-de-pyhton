#8.	Crie um programa que ele calcule um aumento de 15% para um salário de R$ 750. 

salário = 750
Percentual = 15

percentual = Percentual / 100
aumento = percentual * salário
salário_atual = salário + aumento

print('O salário atual:',salário_atual )