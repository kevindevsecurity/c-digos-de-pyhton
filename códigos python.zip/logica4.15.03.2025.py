#criação do retangulo
# criar um retangulo de 6 x 6

linhas = 6
colunas = 6
simbolo = '@'
for l in range(colunas):
    for c in range(colunas):
        print(simbolo, end = ' ')
    print()
    
