'''Adicione o elemento ‘Paulo’ na lista nomes:'''

# Lista inicial
nomes = ['Ana', 'Carlos', 'Daiane', 'Fernando', 'Maria']

# Adiciona 'Paulo' à lista
nomes.append('Paulo')

# Exibe a lista modificada
print(nomes)
