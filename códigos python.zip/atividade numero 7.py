#Escreva um programa que calcule a soma de três variáveis e imprima o resultado na tela. 


v1 = 2
v2 = 3
v3 = 4

Resultado = v1 * v2 + v3
print("O resultado é:", Resultado)