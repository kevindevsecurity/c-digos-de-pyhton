#1. Criando e acessando um dicionario
pessoa = {
    "nome": "João",
    "idade": 30,
    "cidade": "Rio de Janeiro"
}
print(pessoa['nome'])