# Definindo as variáveis
num1 = 52
num2 = 106

# Calculando a soma
resultado = num1 + num2

# Exibindo o resultado
print("O resultado da soma de", num1, "e", num2, "é:", resultado)
