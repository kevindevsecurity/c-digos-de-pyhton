#resultado = 10 + 5

x = int(input("Digite um número: "))
y = int(input("Digite outro número "))
resultado2 = x + y
resultado3 = x - y 
resultado4 = x * y
resultado5 = x / y
resultado6 = x // y
resultado7 = x % y
resultado8 = x ** y

#print("a resposta é:", resultado)
print("a resposta é:", resultado2) 
print("a resposta é:", resultado3) 
print("a resposta é:", resultado4) 
print("a resposta é:", resultado5) 
print("a resposta é:", resultado6) 
print(" O resto da divisão é: ",resultado7)
print(" O número elevado a potencia é: ",resultado8)