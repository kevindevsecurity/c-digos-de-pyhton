#Pedindo a entrada dos valores
dias = int(input("Digite a quantidade de dias: "))
horas = int(input("Digite a quantidade de horas: "))
minutos = int(input("Digite a quantidade de minutos:"))
segundos = int(input("Digite a quantidade de segundos:"))

#Calculando o total em segundos
dia = dias * 86400
hora = horas * 3600
minuto = minutos * 60
segundo = segundos * 1

resultado = dia + hora + minuto + segundo

#Exibindo o resultado
print("O resultado é:", resultado)

