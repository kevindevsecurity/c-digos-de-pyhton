#Convertendo lista para tupla
lista = [5, 10, 15, 20]
tupla = tuple(lista)
print(tupla)
