#Escreva um programa que exiba o resultado de 2x a × 3 x b, em que a vale 3 e b vale 5. 
 

#Questão

a = 3
b = 5


#Resultado

resultado = 2 * a * 3 * b 
print("O resultado é:", resultado)
