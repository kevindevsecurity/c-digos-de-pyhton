import pygame

pygame.init()

window = pygame.display.set_mode([1280, 720])
pygame.display.set_caption("Futeball Pong")

# Carrega imagens
win = pygame.image.load("assets/win.png")
field = pygame.image.load("assets/field.png")
player1 = pygame.image.load("assets/player1.png")
player2 = pygame.image.load("assets/player2.png")
ball = pygame.image.load("assets/ball.png")

# Placar
score1 = 0
score2 = 0
score1_img = pygame.image.load(f"assets/score/{score1}.png")
score2_img = pygame.image.load(f"assets/score/{score2}.png")

# Posições iniciais
player1_y = 310
player2_y = 310
player1_moveup = False
player1_movedown = False
player2_moveup = False
player2_movedown = False

ball_x = 617
ball_y = 337
ball_dir = -5
ball_dir_y = 3

clock = pygame.time.Clock()

def move_player():
    global player1_y, player2_y

    # Jogador 1
    if player1_moveup:
        player1_y -= 5
    if player1_movedown:
        player1_y += 5

    if player1_y < 0:
        player1_y = 0
    elif player1_y > 575:
        player1_y = 575

    # Jogador 2
    if player2_moveup:
        player2_y -= 5
    if player2_movedown:
        player2_y += 5

    if player2_y < 0:
        player2_y = 0
    elif player2_y > 575:
        player2_y = 575

def move_ball():
    global ball_x, ball_y, ball_dir, ball_dir_y
    global score1, score2, score1_img, score2_img

    ball_x += ball_dir
    ball_y += ball_dir_y

    # Colisão com jogador 1
    if ball_x < 120:
        if player1_y < ball_y + 23 and player1_y + 146 > ball_y:
            ball_dir *= -1

    # Colisão com jogador 2
    if ball_x > 1100:
        if player2_y < ball_y + 23 and player2_y + 146 > ball_y:
            ball_dir *= -1

    # Colisão vertical
    if ball_y > 685 or ball_y <= 0:
        ball_dir_y *= -1

    # Gol do jogador 2
    if ball_x < -50:
        ball_x = 617
        ball_y = 337
        ball_dir_y *= -1
        ball_dir *= -1
        score2 += 1
        if score2 <= 9:
            score2_img = pygame.image.load(f"assets/score/{score2}.png")

    # Gol do jogador 1
    elif ball_x > 1320:
        ball_x = 617
        ball_y = 337
        ball_dir_y *= -1
        ball_dir *= -1
        score1 += 1
        if score1 <= 9:
            score1_img = pygame.image.load(f"assets/score/{score1}.png")

def draw():
    if score1 < 9 and score2 < 9:
        window.blit(field, (0, 0))
        window.blit(player1, (50, player1_y))
        window.blit(player2, (1150, player2_y))
        window.blit(ball, (ball_x, ball_y))
        window.blit(score1_img, (500, 50))
        window.blit(score2_img, (710, 50))
        
    else:
        window.blit(win, (300, 300))

# Loop principal
loop = True
while loop:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                player1_moveup = True
            elif event.key == pygame.K_s:
                player1_movedown = True
            elif event.key == pygame.K_o:
                player2_moveup = True
            elif event.key == pygame.K_l:
                player2_movedown = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                player1_moveup = False
            elif event.key == pygame.K_s:
                player1_movedown = False
            elif event.key == pygame.K_o:
                player2_moveup = False
            elif event.key == pygame.K_l:
                player2_movedown = False

    draw()
    move_player()
    move_ball()
    pygame.display.update()
pygame.quit()
