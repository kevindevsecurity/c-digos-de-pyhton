def eh_par(numero):
    return numero % 2 == 0

print(eh_par(4))
print(eh_par(7))

