'''Crie um programa que realiza a contagem de 1 até 100, usando
apenas de números ímpares, ao final do processo exiba em tela
quantos números ímpares foram encontrados nesse intervalo,
assim como a soma dos mesmos:'''

inicio = float(input("Digite o valor inicial: "))
fim = float(input("Digite o valor final: "))

numeros = list(range(int(inicio), int(fim) + 1, 2))  # Lista de números ímpares

i = 0
while i < len(numeros):
    print(numeros[i])
    i += 1

print("Quantidade:", len(numeros))
print("Soma:", sum(numeros))

