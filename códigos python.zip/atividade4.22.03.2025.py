'''4. Modifique o programa anterior para imprimir de 1 até o número digitado 
pelo usuário, mas, dessa vez, apenas os números ímpares.'''

# Programa de contagem com números ímpares até o número fornecido pelo usuário

numero = int(input("Digite um número: "))  
contador = 1  
while contador <= numero:  
    if contador % 2 != 0:  
        print(contador) 
    contador += 1 