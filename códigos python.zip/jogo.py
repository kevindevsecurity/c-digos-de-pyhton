import pygame
pygame.init()

window = pygame.display.set_mode([1280, 720])
window_title = pygame.display.set_caption("Futeball Pong")

loop = True
while loop:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False

pygame.display.update()
pygame.quit()

