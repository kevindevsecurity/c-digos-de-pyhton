a = 4
b = 10
c = 5.0
d = 1
f = 5

#Questão 1
Q1 = a == c 
print(Q1)

#Questão 2
Q2= a < b
print(Q2)

#Questão 3
Q3= d > b
print(Q3)

#Questão 4
Q4 = c != f
print(Q4)

#Questão 5
Q5= a == b
print(Q5)

#Questão 6
Q6= c < d
print(Q6)

#Questão 7
Q7= b > a
print(Q7)

#Questão 8
Q8= c >= f
print(Q8)

#Questão 9
Q9= f >= c 
print(Q9)

#Questão 10
Q10= c <= c
print(Q10)

#Questão 11
Q11= c <= f 
print(Q11)
