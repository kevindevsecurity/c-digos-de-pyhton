preço = 19.99
desconto = 0.1
mensagem = "O preço do produto é R${:.2f} e você tem um desconto de {:.0%}.".format(preço, desconto)
print(mensagem)
