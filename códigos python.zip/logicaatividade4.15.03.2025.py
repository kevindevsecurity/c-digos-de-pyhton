'''4. Verifique se os valores de num1 e de num2 são iguais ou menores que 
100'''

num1 = 100  
num2 = 89   

print(num1 <=100 and num2 <=100)
