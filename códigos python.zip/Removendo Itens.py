#Removendo Itens
pessoa = {
    "nome": "Alice", 
    "idade": 25,
    "cidade": "São Paulo"
}
del pessoa["cidade"]
print(pessoa)
pessoa.pop("idade")
print(pessoa)