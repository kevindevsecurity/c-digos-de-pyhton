#Tabuada

x = int(input("Digite um número: "))
for num in range(1, 11):
    print(f'{x} X {num} = {x * num}')
    

    
