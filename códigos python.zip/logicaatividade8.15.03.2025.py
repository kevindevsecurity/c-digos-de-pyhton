'''Crie um programa que realiza a contagem de 0 a 20, exibindo apenas os 
números pares'''

for i in range(0, 21, 2):
        print(i)
