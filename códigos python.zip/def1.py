def saudacao():
    print("Seja bem-vindo(a) ao curso de Python")
saudacao()