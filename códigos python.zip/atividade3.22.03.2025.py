'''3. Faça um programa para escrever a contagem regressiva do lançamento de 
um foguete. O programa deve imprimir 10, 9, 8, … , 1, 0 e Fogo! na tela.'''

# Programa de contagem regressiva do lançamento de um foguete

contador = 10  
while contador >= 0:  
    print(contador)  
    contador -= 1 

print("Fogo!")
