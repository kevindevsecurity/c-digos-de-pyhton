#Digite a seguinte expressão no interpretador: 10 % 3 * 10 ** 2 + 1 - 10 * 4 / 2 Tente resolver o mesmo cálculo, usando apenas lápis e papel. Observe como a prioridade das operações é importante. 


#Questão

a = 10
b = 3
c = 2
d = 1
e = 4
f = 2

#Resultado
resultado = a % b * a ** c + d - a * e / f
print("O resultado é:", resultado)


