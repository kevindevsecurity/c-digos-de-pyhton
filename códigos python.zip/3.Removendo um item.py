#3.Removendo um item
pessoa = {
    "nome": "João",
    "idade": 30,
    "cidade": "Rio de Janeiro"
}
del pessoa ["cidade"]
print(pessoa)

