def saudacao(nome):
    print(f"Olá,{nome}! Seja bem-vindo(a).")
saudacao("Kevin")