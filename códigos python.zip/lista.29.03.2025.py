#Lista
lista = (1, 2, 3, 4, 5)
print(lista)

#Acessar a lista
numeros = [1, 2, 3, 4, 5]
print(numeros[0])
print(numeros[-1])


