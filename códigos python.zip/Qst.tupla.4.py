#4. Concatenação de tuplas
tupla = (1, 2, 3)
nova_tupla = tupla + (4, 5, 6)
print(nova_tupla)
