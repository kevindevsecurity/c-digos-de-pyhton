def imprimir_lista(lista):
    for item in lista:
        print(item)

minha_lista = ["Espada", "Escudo", "Arco", "Flecha", "Frutas", "Armadura", "Bombas", "Máscara"]
imprimir_lista(minha_lista)
